#!/bin/bash

echo "Setting up apps/ifx/TLE5012B sym link..."
ln -s -r app ../../../../../../../apps/ifx/TLE5012B
echo "Library configured successfully.
